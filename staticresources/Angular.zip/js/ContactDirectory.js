var contactDirectory = {};

contactDirectory.getContactsInitStr = '';

var app = angular.module('MyApp', ['PaginatorApp']);

app.directive('ngEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if(event.which === 13) {
				scope.getContacts();			 
                event.preventDefault();
            }
        });
    };
});  

app.controller('myController', ['$scope', 'Pagination', function($scope, Pagination){

	var cIndex; 			
		
	$scope.deleteContact = function(cid, index){
		cIndex = index;
		var ct = new SObjectModel.CT();   					
		ct.del(cid, $scope.handleDelete); 					
	}       
	
	$scope.handleDelete = function(err, ids){

	    if (err) { 
			alert(err);
	    } 
	    else {
			$scope.getContacts();			    				
    	}
	}  		
	
	$scope.toggleSort = function(field){
		
		var orderByChanged = field != $scope.orderBy;
		$scope.orderBy = field;
		$scope.orderAsc = orderByChanged ? true : !$scope.orderAsc;
		$scope.getContacts();	    			    		
	}	
	
    $scope.pagination = Pagination.getNew(5); 	 		    	
	
	$scope.setDefaults = function(onSearch){
    	$scope.searchTxt = onSearch ? $scope.searchTxt : '';
    	$scope.orderBy = 'Name';
    	$scope.orderAsc = true;	  
        $scope.pagination.pageSize = 5;
       	$scope.pagination.offSet = 0;  	
       	$scope.pagination.recordCount = 0;    
       	$scope.pagination.totalPages = 0;
       	$scope.pagination.pages = []; 	
       	$scope.pagination.currentPage = 1;	        	  			
	}		
	
	$scope.setDefaults(false);	

    $scope.getContacts = function(){
    
    	Visualforce.remoting.Manager.invokeAction(
        contactDirectory.getContactsInitStr,
        $scope.searchTxt, $scope.pagination.pageSize, $scope.pagination.offSet, $scope.orderBy, $scope.orderAsc ? 'ASC' : 'DESC',
        function(result, event){
            if (event.status) {
				$scope.contacts = result.contacts;
				$scope.pagination.recordCount = result.recordCount;
				$scope.pagination.totalPages = Math.ceil($scope.pagination.recordCount / $scope.pagination.pageSize);					
				$scope.pagination.pages = [];
				
				for (i = 1; i <= $scope.pagination.totalPages; i++){
					$scope.pagination.pages.push(i);
				}
				
				$scope.$apply();
            }
            else {
                alert(event.message);
            }
        }, 
        {escape: true}
    	);           
    }	
    
    $scope.onSearch = function(){
		$scope.setDefaults(true);
    	$scope.getContacts();
	}
	
    $scope.onClearSearch = function(){
		$scope.setDefaults(false); 
		$scope.getContacts();
	}        		           

    $scope.getContacts();
}]); 