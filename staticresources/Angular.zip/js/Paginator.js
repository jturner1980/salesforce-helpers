(function() {

    var pageApp = angular.module('PaginatorApp', []);

	pageApp.factory('Pagination', function() {

 		var pagination = {};

		pagination.getNew = function(pageSize) {
			
			pageSize = pageSize === undefined ? 5 : pageSize;

			var paginator = {
    			pageSize: pageSize,
				recordCount: 0,
				totalPages: 0,
				pages: [],
				currentPage: 1
			};
		
	 		paginator.previous = function(){
	 			paginator.offSet = paginator.offSet - paginator.pageSize >= 0 ? paginator.offSet - paginator.pageSize : 0;
	 			paginator.currentPage--;
	 		}	 
	 
	 		paginator.next = function(){
	 			paginator.offSet += paginator.pageSize;
	 			paginator.currentPage++;
	 		}
	 		
	 		paginator.goToPage = function(pg){
				paginator.currentPage = pg;
				paginator.offSet = (pg - 1) * paginator.pageSize;
	 		} 	

			return paginator;        	
		}

		return pagination;
	});   

})();